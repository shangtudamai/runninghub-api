import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';

interface ImageCompareSliderProps {
  beforeImage: string;
  afterImage: string;
  beforeLabel?: string;
  afterLabel?: string;
}

export const ImageCompareSlider: React.FC<ImageCompareSliderProps> = ({
  beforeImage,
  afterImage,
  beforeLabel = '原图',
  afterLabel = '修复后'
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [sliderPosition, setSliderPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const [imageDimensions, setImageDimensions] = useState({ width: 0, height: 0 });
  
  // 初始化滑块并获取图片尺寸
  useEffect(() => {
    if (containerRef.current) {
      // 确保容器加载完成后设置默认尺寸
      const rect = containerRef.current.getBoundingClientRect();
      setImageDimensions({ 
        width: rect.width, 
        height: rect.height 
      });
    }
    
    // 预加载图片以确保它们有相同的尺寸
    const preloadImages = async () => {
      const [beforeImg, afterImg] = await Promise.all([
        loadImage(beforeImage),
        loadImage(afterImage)
      ]);
      
      // 使用最大的尺寸作为参考，确保两张图片都能完全显示
      if (beforeImg && afterImg && containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        const maxWidth = rect.width;
        const maxHeight = 400; // 设置一个合理的最大高度
        
        // 计算两张图片的最佳显示尺寸
        const beforeRatio = Math.min(maxWidth / beforeImg.width, maxHeight / beforeImg.height, 1);
        const afterRatio = Math.min(maxWidth / afterImg.width, maxHeight / afterImg.height, 1);
        const ratio = Math.min(beforeRatio, afterRatio);
        
        setImageDimensions({
          width: maxWidth,
          height: Math.min(beforeImg.height * ratio, afterImg.height * ratio, maxHeight)
        });
      }
    };
    
    preloadImages();
  }, [beforeImage, afterImage]);
  
  // 辅助函数：加载图片获取尺寸
  const loadImage = (src: string): Promise<HTMLImageElement | null> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => resolve(null);
      img.src = src;
    });
  };
  
  // 处理鼠标和触摸事件
  const handleDragStart = () => {
    setIsDragging(true);
  };
  
  const handleDragEnd = () => {
    setIsDragging(false);
  };
  
  const handleMouseMove = (e: MouseEvent) => {
    if (isDragging && containerRef.current) {
      updateSliderPosition(e.clientX);
    }
  };
  
  const handleTouchMove = (e: TouchEvent) => {
    if (isDragging && containerRef.current) {
      updateSliderPosition(e.touches[0].clientX);
    }
  };
  
  // 更新滑块位置
  const updateSliderPosition = (clientX: number) => {
    if (!containerRef.current) return;
    
    const rect = containerRef.current.getBoundingClientRect();
    const offsetX = Math.min(Math.max(clientX - rect.left, 0), rect.width);
    const percent = (offsetX / rect.width) * 100;
    setSliderPosition(percent);
  };
  
  // 事件监听
  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('touchmove', handleTouchMove, { passive: false });
      
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('touchmove', handleTouchMove);
      };
    }
  }, [isDragging]);
  
  useEffect(() => {
    window.addEventListener('mouseup', handleDragEnd);
    window.addEventListener('touchend', handleDragEnd);
    
    return () => {
      window.removeEventListener('mouseup', handleDragEnd);
      window.removeEventListener('touchend', handleDragEnd);
    };
  }, []);
  
  // 获取当前主题
  const isDarkMode = document.documentElement.classList.contains('dark');
  
  // 当窗口大小改变时重新计算尺寸
  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setImageDimensions(prev => ({ ...prev, width: rect.width }));
      }
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  return (
    <motion.div 
      id="compareContainer"
      ref={containerRef} 
      className={`compare-container relative inline-block w-full max-w-[600px] rounded-2xl overflow-hidden shadow-xl ${
        isDarkMode ? 'shadow-blue-500/5' : 'shadow-blue-500/10'
      }`}
      style={{
        height: `${imageDimensions.height}px`,
        minHeight: '200px'
      }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* 原图容器 - 确保与修复后图片相同大小 */}
      <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
        <img 
          src={beforeImage} 
          alt={beforeLabel} 
          className="w-full h-full object-contain"
          loading="lazy"
        />
      </div>
      
      {/* 修复后图片覆盖层 */}
      <div 
        id="overlay"
        className="compare-overlay absolute top-0 left-0 h-full overflow-hidden flex items-center justify-center"
        style={{ width: `${sliderPosition}%` }}
      >
        <img 
          src={afterImage} 
          alt={afterLabel} 
          className="w-full h-full object-contain"
          loading="lazy"
        />
        {/* 渐变遮罩，增强视觉效果 */}
        <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-black/20 to-transparent"></div>
      </div>
      
      {/* 滑块 */}
      <div 
        id="slider"
        className="slider absolute top-0 w-[3px] h-full bg-blue-500/90 cursor-ew-resize shadow-md shadow-blue-500/30"
        style={{ left: `${sliderPosition}%` }}
        onMouseDown={handleDragStart}
        onTouchStart={handleDragStart}
      >
        <motion.div 
          className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 border-4 border-white shadow-lg flex items-center justify-center"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <i className="fa-solid fa-arrows-left-right text-white text-sm"></i>
        </motion.div>
      </div>
      
      {/* 标签 */}
      <div className="absolute top-4 left-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium shadow-md">
        {beforeLabel}
      </div>
      <div className="absolute top-4 right-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium shadow-md">
        {afterLabel}
      </div>
    </motion.div>
  );
};