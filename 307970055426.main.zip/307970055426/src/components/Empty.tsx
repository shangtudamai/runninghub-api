import { toast } from "sonner";
import { cn } from "@/lib/utils";

// 修复鸭主题的空状态组件
export function Empty() {
  return (
    <div 
      className="flex h-full items-center justify-center flex-col p-8 text-white" 
      onClick={() => toast('Coming soon')}
    >
      <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4 bg-white/20 backdrop-blur-sm">
        <i className="fa-solid fa-plus text-xl"></i>
      </div>
      <p className="text-base">暂无内容</p>
    </div>
  );
}