import { createContext } from "react";

export interface UserData {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  avatar?: string;
  isMember: boolean;
  memberExpiry?: string;
}

export interface AuthContextType {
  isAuthenticated: boolean;
  user: UserData | null;
  setIsAuthenticated: (value: boolean) => void;
  setUser: (user: UserData | null) => void;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  user: null,
  setIsAuthenticated: (value: boolean) => {},
  setUser: (user: UserData | null) => {},
  logout: () => {},
});