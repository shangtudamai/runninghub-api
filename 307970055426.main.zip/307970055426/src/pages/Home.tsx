import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { usePhotoRestore } from "@/hooks/usePhotoRestore";

// 使用指定的图片作为背景
const BACKGROUND_IMAGE = "https://lf-code-agent.coze.cn/obj/x-ai-cn/307970055426/attachment/老照片修复小程序%20UI%20设计%20(6)_20251118013855.png";

// 模拟修复后的图片
const MOCK_RESTORED_IMAGE = "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Restored%20vintage%20photo%20with%20high%20quality%20and%20clarity&sign=7c53dc2468ae30f6dc56f76fcdd37074";

export default function Home() {
  const navigate = useNavigate();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [damageLevel, setDamageLevel] = useState<'light' | 'severe'>('light');
  const [showResult, setShowResult] = useState(false);
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string | null>(null);
  const [restoredImageUrl, setRestoredImageUrl] = useState<string | null>(null);

  // 使用照片修复的hooks
  const { 
    resultUrl, 
    error, 
    loading, 
    restorePhoto, 
    useSampleResult, 
    clearResult 
  } = usePhotoRestore();

  // 监听修复结果变化
  useEffect(() => {
    if (resultUrl) {
      setRestoredImageUrl(resultUrl);
      setShowResult(true);
    }
  }, [resultUrl]);

  // 处理文件上传
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // 验证文件类型
    const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/bmp'];
    if (!validTypes.includes(file.type)) {
      toast.error("请上传有效的图片文件");
      return;
    }
    
    // 验证文件大小（最大10MB）
    if (file.size > 10 * 1024 * 1024) {
      toast.error("图片大小不能超过10MB");
      return;
    }
    
    setSelectedFile(file);
    
    // 创建预览URL
    const reader = new FileReader();
    reader.onload = (ev) => {
      if (ev.target?.result) {
        setUploadedImageUrl(ev.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  // 点击修复按钮
  const handleRestore = async () => {
    if (!selectedFile) {
      toast.error("请先选择一张照片！");
      return;
    }

    try {
      // 调用修复函数
      await restorePhoto(selectedFile);
    } catch (err) {
      toast.error("修复过程中发生错误，请重试");
    }
  };

  // 处理导航
  const handleNavigate = (path: string) => {
    navigate(path);
  };

  // 返回首页，重置状态
  const handleBackToHome = () => {
    setShowResult(false);
    setSelectedFile(null);
    setUploadedImageUrl(null);
    setRestoredImageUrl(null);
    clearResult();
  };

  // 关闭预览图
  const handleClosePreview = () => {
    setSelectedFile(null);
    setUploadedImageUrl(null);
  };

  // 下载修复后的图片
  const handleDownload = () => {
    if (!restoredImageUrl) return;
    
    const link = document.createElement('a');
    link.href = restoredImageUrl;
    link.download = 'restored-photo.jpg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success("图片已开始下载");
  };

  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-between relative"
      style={{
        backgroundImage: `url(${BACKGROUND_IMAGE})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
      }}
    >
      {/* 主要内容区域 */}
      {!showResult ? (
        // 首页状态
        <motion.div 
          className="w-full flex flex-col items-center justify-between min-h-screen px-6 pt-10 pb-36"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          {/* 标题和图标已包含在背景图中，无需额外添加 */}
          
           {/* 中间内容区域 - 预览图、损坏程度选择和修复按钮 */}
          <div className="w-full max-w-xs mt-6 mb-auto flex flex-col gap-6">
            {/* 预览图区域 - 仅在选择文件后显示 */}
            {uploadedImageUrl && (
              <motion.div 
                className="w-full bg-white/80 backdrop-blur-sm rounded-xl p-4 shadow-lg relative"
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5, duration: 0.5 }}
              >
                {/* 红色关闭按钮 */}
                <button 
                  className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-red-500 text-white flex items-center justify-center shadow-md z-10"
                  onClick={handleClosePreview}
                >
                  <i className="fa-solid fa-times text-xs"></i>
                </button>
                
                <p className="text-[#166534] font-medium mb-3 text-center">预览图</p>
                <div className="aspect-square bg-gray-200 rounded-lg overflow-hidden flex items-center justify-center">
                  <img 
                    src={uploadedImageUrl} 
                    alt="预览图" 
                    className="w-full h-full object-contain"
                  />
                </div>
              </motion.div>
            )}
            
            {/* 损坏程度选择区域 - 仅在选择文件后显示 */}
            {selectedFile && (
              <motion.div 
                className="w-full bg-white/80 backdrop-blur-sm rounded-xl p-4 shadow-lg"
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6, duration: 0.5 }}
              >
                <p className="text-[#166534] font-medium mb-3 text-center">选择照片损坏程度</p>
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setDamageLevel('light')}
                    className={`flex-1 py-3 rounded-xl transition-all duration-300 ${
                      damageLevel === 'light' 
                        ? 'bg-[#22c55e] text-white shadow-md' 
                        : 'bg-white/70 text-[#166534] hover:bg-white/90'
                    }`}
                  >
                    <i className="fa-solid fa-wand-magic-sparkles mr-1"></i> 轻微损坏
                  </button>
                  <button
                    type="button"
                    onClick={() => setDamageLevel('severe')}
                    className={`flex-1 py-3 rounded-xl transition-all duration-300 ${
                      damageLevel === 'severe' 
                        ? 'bg-[#22c55e] text-white shadow-md' 
                        : 'bg-white/70 text-[#166534] hover:bg-white/90'
                    }`}
                  >
                    <i className="fa-solid fa-toolbox mr-1"></i> 严重损坏
                  </button>
                </div>
                <p className="mt-2 text-xs text-[#16a34a]/80 text-center">
                  {damageLevel === 'light' 
                    ? '适合有轻微划痕、褪色的照片' 
                    : '适合有严重裂痕、缺失部分的照片'
                  }
                </p>
              </motion.div>
            )}
            
            {/* 点击修复按钮 - 仅在选择文件后显示 */}
            {selectedFile && (
              <motion.div 
                className="w-full"
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7, duration: 0.5 }}
              >
                <button
                  onClick={handleRestore}
                  disabled={loading}
                  className={`w-full py-6 bg-[#b6f8cf] text-[#166534] font-medium rounded-full text-lg shadow-lg hover:shadow-xl transition-all duration-300 ${
                    loading ? "opacity-70 cursor-not-allowed" : ""
                  }`}
                >
                  {loading ? "修复中..." : "点击修复"}
                </button>
              </motion.div>
            )}
          </div>
          
          {/* 下方上传照片按钮区域 - 只在没有选择文件时显示 */}
          {!selectedFile && (
            <motion.div 
              className="w-full max-w-xs"
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.8 }}
            >
              <button
                onClick={() => document.getElementById("fileInput")?.click()}
                className="w-full py-6 bg-[#b6f8cf] text-[#166534] font-medium rounded-full text-lg shadow-lg hover:shadow-xl transition-all duration-300"
              >
                上传照片
              </button>
              <input
                type="file"
                id="fileInput"
                accept="image/*"
                className="hidden"
                onChange={handleFileChange}
              />
            </motion.div>
          )}
          
          {/* 错误信息显示 */}
          {error && (
            <motion.div 
              className="fixed top-10 px-4 py-2 bg-red-100 text-red-600 rounded-lg text-sm"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              {error}
            </motion.div>
          )}
        </motion.div>
      ) : (
        // 修复结果状态
        <motion.div 
          className="w-full flex flex-col items-center justify-center min-h-screen px-6 pb-24"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <motion.div 
            className="w-full max-w-xs"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          >
            <h2 className="text-[#166534] font-bold text-2xl mb-6 text-center">修复完成</h2>
            
            {/* 修复结果图片 */}
            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-4 shadow-lg mb-6">
              <div className="aspect-square bg-gray-200 rounded-lg overflow-hidden flex items-center justify-center">
                {restoredImageUrl ? (
                  <img 
                    src={restoredImageUrl} 
                    alt="修复后" 
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <div className="w-10 h-10 border-4 border-[#22c55e] border-t-transparent rounded-full animate-spin"></div>
                  </div>
                )}
              </div>
            </div>
            
            {/* 操作按钮 */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <button
                onClick={handleDownload}
                disabled={!restoredImageUrl}
                className={`py-4 bg-[#22c55e] text-white font-medium rounded-full text-sm shadow-lg hover:shadow-xl transition-all duration-300 ${
                  !restoredImageUrl ? "opacity-70 cursor-not-allowed" : ""
                }`}
              >
                <i className="fa-solid fa-download mr-1"></i> 下载图片
              </button>
              <button
                onClick={handleBackToHome}
                className="py-4 bg-[#b6f8cf] text-[#166534] font-medium rounded-full text-sm shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <i className="fa-solid fa-arrow-left mr-1"></i> 返回首页
              </button>
            </div>
            
            {/* 错误信息显示 */}
            {error && (
              <motion.div 
                className="mt-4 px-4 py-2 bg-red-100 text-red-600 rounded-lg text-sm"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                {error}
              </motion.div>
            )}
          </motion.div>
        </motion.div>
      )}
      
      {/* 底部导航 */}
      <motion.div 
        className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-md border-t border-[#86efac] flex justify-around py-3 px-6"
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ delay: 0.5, duration: 0.5 }}
      >
<motion.div 
  className="modern-nav-item active"
  onClick={() => handleNavigate('/')}
  whileHover={{ scale: 1.03 }}
  whileTap={{ scale: 0.98 }}
>
  <i className="fa-solid fa-paint-brush"></i>
  <span>修复台</span>
</motion.div>
        <motion.div 
          className="modern-nav-item"
          onClick={() => handleNavigate('/profile')}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.98 }}
        >
           <i className="fa-solid fa-user"></i>
           <span>个人中心</span>
         </motion.div>
      </motion.div>
    </div>
  );
}
