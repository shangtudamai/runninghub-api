import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { useContext } from "react";
import { AuthContext } from "@/contexts/authContext";

// 定义图片历史记录的类型
interface ImageHistory {
  id: string;
  originalImage: string;
  restoredImage: string;
  timestamp: string;
  damageLevel: "light" | "severe";
}

// 模拟图片历史记录数据
const mockImageHistory: ImageHistory[] = [
  {
    id: "1",
    originalImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Old%20damaged%20photo%20of%20a%20vintage%20family&sign=74725181ae98280be69201dda7570402",
    restoredImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Restored%20vintage%20photo%20with%20high%20quality&sign=df02c037da14dcf3b853df20b4fb8c20",
    timestamp: "2025-11-19 14:30:25",
    damageLevel: "light",
  },
  {
    id: "2",
    originalImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Old%20damaged%20photo%20of%20a%20vintage%20car&sign=3e0ed273e05791f2c4c79a3760a4ffae",
    restoredImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Restored%20vintage%20car%20photo%20with%20high%20quality&sign=52046c28928179c7bea074fea511866a",
    timestamp: "2025-11-18 09:15:42",
    damageLevel: "severe",
  },
  {
    id: "3",
    originalImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Old%20damaged%20photo%20of%20a%20vintage%20house&sign=73f391eca25e808860078c4531db3908",
    restoredImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Restored%20vintage%20house%20photo%20with%20high%20quality&sign=426b72f116ab3a964d29d3b8892ced3a",
    timestamp: "2025-11-17 16:45:11",
    damageLevel: "light",
  },
  {
    id: "4",
    originalImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Old%20damaged%20photo%20of%20a%20vintage%20city&sign=d850d30baaee4f5ce9bc4bf2da7df24d",
    restoredImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Restored%20vintage%20city%20photo%20with%20high%20quality&sign=51688429b72cd66ce22dcb5a90688821",
    timestamp: "2025-11-16 11:20:33",
    damageLevel: "severe",
  },
  {
    id: "5",
    originalImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Old%20damaged%20photo%20of%20a%20vintage%20nature&sign=be596e36291bf125901a002bc42ade85",
    restoredImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Restored%20vintage%20nature%20photo%20with%20high%20quality&sign=a080bb2ff21f84c89c6ff39035b84759",
    timestamp: "2025-11-15 18:05:17",
    damageLevel: "light",
  },
];

export default function Profile() {
  const navigate = useNavigate();
  const { isAuthenticated, user, setIsAuthenticated, setUser, logout } = useContext(AuthContext);
  const [phone, setPhone] = useState("");
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [imageHistory, setImageHistory] = useState<ImageHistory[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  // 新增多选相关状态
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [isManageMode, setIsManageMode] = useState(false);
  
  // 新增图片预览状态
  const [showImagePreview, setShowImagePreview] = useState(false);
  const [previewImageUrl, setPreviewImageUrl] = useState("");

  // 加载图片历史记录
  useEffect(() => {
    if (isAuthenticated) {
      // 模拟从本地存储加载历史记录
      const savedHistory = localStorage.getItem('imageHistory');
      if (savedHistory) {
        try {
          setImageHistory(JSON.parse(savedHistory));
        } catch (error) {
          // 如果解析失败，使用模拟数据
          setImageHistory(mockImageHistory);
        }
      } else {
        // 首次加载，使用模拟数据
        setImageHistory(mockImageHistory);
        // 保存到本地存储
        localStorage.setItem('imageHistory', JSON.stringify(mockImageHistory));
      }
    }
  }, [isAuthenticated]);

  // 从本地存储恢复认证状态
  useEffect(() => {
    const savedIsAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
    const savedUser = localStorage.getItem('user');
    
    if (savedIsAuthenticated && savedUser) {
      try {
        setIsAuthenticated(savedIsAuthenticated);
        setUser(JSON.parse(savedUser));
      } catch (error) {
        console.error('Failed to load user data from localStorage');
      }
    }
  }, [setIsAuthenticated, setUser]);

  // 处理手机号登录
  const handlePhoneLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!phone || !/^1[3-9]\d{9}$/.test(phone)) {
      toast.error("请输入有效的手机号码");
      return;
    }
    
    setIsLoading(true);
    
    // 模拟登录过程
    setTimeout(() => {
      const mockUser = {
        id: `user_${Date.now()}`,
        name: `用户${phone.substring(7)}`,
        phone: phone,
        isMember: false,
        avatar: `https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=User%20avatar%20for%20profile&sign=63006132819f90825e7d503916987030`,
      };
      
      setIsAuthenticated(true);
      setUser(mockUser);
      setShowLoginForm(false);
      
      // 保存到本地存储
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('user', JSON.stringify(mockUser));
      
      toast.success(`欢迎，${mockUser.name}！`);
      setIsLoading(false);
    }, 1500);
  };

  // 处理第三方登录（谷歌、微信）
  const handleThirdPartyLogin = (provider: 'google' | 'wechat') => {
    setIsLoading(true);
    
    // 模拟第三方登录过程
    setTimeout(() => {
      const mockUser = {
        id: `user_${provider}_${Date.now()}`,
        name: provider === 'google' ? 'Google用户' : '微信用户',
        email: provider === 'google' ? 'user@gmail.com' : undefined,
        isMember: provider === 'google' ? true : false,
        memberExpiry: provider === 'google' ? '2026-11-20' : undefined,
        avatar: `https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=${provider}%20user%20avatar&sign=${Date.now()}`,
      };
      
      setIsAuthenticated(true);
      setUser(mockUser);
      
      // 保存到本地存储
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('user', JSON.stringify(mockUser));
      
      toast.success(`欢迎，${mockUser.name}！`);
      setIsLoading(false);
    }, 1500);
  };

  // 下载图片
  const handleDownloadImage = (imageUrl: string, id: string) => {
    // 创建一个临时canvas来处理跨域图片下载
    const downloadImage = async () => {
      try {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const img = new Image();
        
        // 设置跨域属性
        img.crossOrigin = 'anonymous';
        
        img.onload = () => {
          canvas.width = img.width;
          canvas.height = img.height;
          if (ctx) {
            ctx.drawImage(img, 0, 0);
            
            // 将canvas转换为blob并下载
            canvas.toBlob((blob) => {
              if (blob) {
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `restored_photo_${id}.jpg`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);
                
                toast.success("图片已开始下载");
              } else {
                toast.error("无法创建下载文件");
              }
            });
          }
        };
        
        img.onerror = () => {
          // 如果canvas方式失败，尝试直接下载
          const link = document.createElement('a');
          link.href = imageUrl;
          link.download = `restored_photo_${id}.jpg`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          
          toast.success("图片已开始下载");
        };
        
        img.src = imageUrl;
      } catch (error) {
        console.error("下载图片失败:", error);
        toast.error("下载图片时发生错误");
      }
    };
    
    downloadImage();
  };

  // 删除图片
  const handleDeleteImage = (id: string) => {
    if (window.confirm("确定要删除这张图片吗？")) {
      const updatedHistory = imageHistory.filter(image => image.id !== id);
      setImageHistory(updatedHistory);
      
      // 更新本地存储
      localStorage.setItem('imageHistory', JSON.stringify(updatedHistory));
      
      toast.success("图片已删除");
    }
  };

  // 处理退出登录
  const handleLogout = () => {
    logout();
    toast.success("已退出登录");
  };

  // 处理图片选择
  const handleImageSelect = (id: string) => {
    setSelectedImages(prevSelected => {
      if (prevSelected.includes(id)) {
        return prevSelected.filter(imageId => imageId !== id);
      } else {
        return [...prevSelected, id];
      }
    });
  };

  // 处理全选/取消全选
  const handleSelectAll = () => {
    if (selectedImages.length === imageHistory.length) {
      setSelectedImages([]);
    } else {
      setSelectedImages(imageHistory.map(image => image.id));
    }
  };

  // 批量下载图片
  const handleBatchDownload = () => {
    if (selectedImages.length === 0) {
      toast.error("请先选择要下载的图片");
      return;
    }
    
    // 下载所有选中的图片
    selectedImages.forEach((id, index) => {
      const image = imageHistory.find(img => img.id === id);
      if (image) {
        // 为防止浏览器阻止多个下载请求，添加延迟
        setTimeout(() => {
          handleDownloadImage(image.restoredImage, image.id);
        }, index * 300);
      }
    });
    
    toast.success(`已开始下载${selectedImages.length}张图片`);
  };

  // 批量删除图片
  const handleBatchDelete = () => {
    if (selectedImages.length === 0) {
      toast.error("请先选择要删除的图片");
      return;
    }
    
    if (window.confirm(`确定要删除选中的${selectedImages.length}张图片吗？`)) {
      const updatedHistory = imageHistory.filter(image => !selectedImages.includes(image.id));
      setImageHistory(updatedHistory);
      
      // 更新本地存储
      localStorage.setItem('imageHistory', JSON.stringify(updatedHistory));
      
      toast.success(`已删除${selectedImages.length}张图片`);
      setSelectedImages([]);
      setIsManageMode(false);
    }
  };
  
  // 显示图片预览
  const handleImagePreview = (imageUrl: string) => {
    setPreviewImageUrl(imageUrl);
    setShowImagePreview(true);
  };
  
  // 关闭图片预览
  const handleClosePreview = () => {
    setShowImagePreview(false);
    setPreviewImageUrl("");
  };

  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-between relative bg-gradient-to-b from-[#f0fdf4] to-white"
    >
      {/* 主要内容区域 */}
      <motion.div 
        className="w-full flex flex-col items-center min-h-screen px-6 pt-10 pb-36"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
         {/* 移除页面标题 */}
         
        {!isAuthenticated ? (
          // 未登录状态
          <motion.div 
            className="w-full max-w-xs bg-white/80 backdrop-blur-sm rounded-xl p-6 shadow-lg"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
          >
            {showLoginForm ? (
              // 手机号登录表单
              <div className="space-y-4">
                <h2 className="text-[#166534] font-medium text-center text-lg">手机号登录</h2>
                <form onSubmit={handlePhoneLogin} className="space-y-4">
                  <div>
                    <input
                      type="tel"
                      placeholder="请输入手机号码"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-[#86efac] focus:outline-none focus:ring-2 focus:ring-[#22c55e] focus:border-transparent"
                      maxLength={11}
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={isLoading}
                    className={`w-full py-3 bg-[#22c55e] text-white font-medium rounded-xl transition-all duration-300 ${
                      isLoading ? "opacity-70 cursor-not-allowed" : ""
                    }`}
                  >
                    {isLoading ? "登录中..." : "登录"}
                  </button>
                </form>
                <button
                  onClick={() => setShowLoginForm(false)}
                  className="w-full py-2 text-[#166534] text-center text-sm"
                >
                  返回选择登录方式
                </button>
              </div>
            ) : (
              // 登录方式选择
              <div className="space-y-6">
                <h2 className="text-[#166534] font-medium text-center text-lg">请选择登录方式</h2>
                
                {/* 手机号登录按钮 */}
                <button
                  onClick={() => setShowLoginForm(true)}
                  className="w-full py-4 bg-white rounded-xl border border-[#86efac] text-[#166534] font-medium transition-all duration-300 flex items-center justify-center"
                >
                  <i className="fa-solid fa-mobile-screen text-xl mr-2"></i>
                  手机号登录
                </button>
                
                {/* 谷歌登录按钮 */}
                <button
                  onClick={() => handleThirdPartyLogin('google')}
                  disabled={isLoading}
                  className={`w-full py-4 bg-white rounded-xl border border-[#86efac] text-[#166534] font-medium transition-all duration-300 flex items-center justify-center ${
                    isLoading ? "opacity-70 cursor-not-allowed" : ""
                  }`}
                >
                  <i className="fa-brands fa-google text-xl mr-2"></i>
                  谷歌账号登录
                </button>
                
                {/* 微信登录按钮 */}
                <button
                  onClick={() => handleThirdPartyLogin('wechat')}
                  disabled={isLoading}
                  className={`w-full py-4 bg-white rounded-xl border border-[#86efac] text-[#166534] font-medium transition-all duration-300 flex items-center justify-center ${
                    isLoading ? "opacity-70 cursor-not-allowed" : ""
                  }`}
                >
                  <i className="fa-brands fa-weixin text-xl mr-2 text-green-500"></i>
                  微信登录
                </button>
                
                {/* 登录提示 */}
                <p className="text-xs text-[#16a34a]/70 text-center">
                  登录后可查看历史修复记录和会员信息
                </p>
              </div>
            )}
          </motion.div>
        ) : (
          // 已登录状态
          <>
            {/* 用户信息卡片 */}
            <motion.div 
              className="w-full max-w-xs bg-white/80 backdrop-blur-sm rounded-xl p-6 shadow-lg mb-6"
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.5 }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-[#22c55e]">
                    <img 
                      src={user?.avatar || "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=User%20avatar%20placeholder&sign=83c085feac932e529530b70931cb7c23"} 
                      alt="用户头像" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h2 className="text-[#166534] font-bold">{user?.name}</h2>
                    {user?.phone && <p className="text-sm text-[#16a34a]/70">{user.phone}</p>}
                    {user?.email && <p className="text-sm text-[#16a34a]/70">{user.email}</p>}
                  </div>
                </div>
                <button
                  onClick={handleLogout}
                  className="w-8 h-8 rounded-full bg-[#f87171] flex items-center justify-center"
                >
                  <i className="fa-solid fa-right-from-bracket text-white"></i>
                </button>
              </div>
              
              {/* 会员信息 */}
              <div className="mt-4 pt-4 border-t border-[#86efac]/30">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-[#16a34a]">会员状态</span>
                  <span className={`text-sm font-medium ${
                    user?.isMember ? "text-[#f59e0b]" : "text-[#16a34a]"
                  }`}>
                    {user?.isMember ? "会员" : "普通用户"}
                  </span>
                </div>
                {user?.isMember && user?.memberExpiry && (
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-sm text-[#16a34a]">会员到期</span>
                    <span className="text-sm text-[#16a34a]">{user.memberExpiry}</span>
                  </div>
                )}
              </div>
            </motion.div>
            
            {/* 历史记录区域 */}
            <motion.div 
              className="w-full max-w-xs"
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.5 }}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-[#166534] font-medium flex items-center">
                  <i className="fa-solid fa-clock-rotate-left mr-2"></i>
                  历史修复记录
                </h2>
                
                {/* 统一管理按钮 */}
                {imageHistory.length > 0 && (
                  <button
                    onClick={() => {
                      setIsManageMode(!isManageMode);
                      setSelectedImages([]);
                    }}
                    className="text-sm text-[#166534] font-medium flex items-center"
                  >
                    {isManageMode ? (
                      <>
                        <i className="fa-solid fa-check mr-1"></i>
                        完成
                      </>
                    ) : (
                      <>
                        <i className="fa-solid fa-ellipsis-vertical mr-1"></i>
                        管理
                      </>
                    )}
                  </button>
                )}
              </div>
              
              {imageHistory.length > 0 ? (
                <>
                  {/* 管理模式下的操作栏 */}
                  {isManageMode && (
                    <div className="bg-white/80 backdrop-blur-sm rounded-xl p-3 mb-4 flex items-center justify-between">
                      <button
                        onClick={handleSelectAll}
                        className="text-sm text-[#166534] flex items-center"
                      >
                        <i 
                          className={`fa-solid mr-1 ${
                            selectedImages.length === imageHistory.length 
                              ? "fa-check-square" 
                              : "fa-square"
                          }`}
                        ></i>
                        全选
                      </button>
                      <div className="flex gap-2">
                        <button
                          onClick={handleBatchDownload}
                          className="px-3 py-1 bg-[#22c55e] text-white text-xs rounded-full flex items-center"
                          disabled={selectedImages.length === 0}
                        >
                          <i className="fa-solid fa-download mr-1"></i>
                          下载
                        </button>
                        <button
                          onClick={handleBatchDelete}
                          className="px-3 py-1 bg-[#f87171] text-white text-xs rounded-full flex items-center"
                          disabled={selectedImages.length === 0}
                        >
                          <i className="fa-solid fa-trash mr-1"></i>
                          删除
                        </button>
                      </div>
                    </div>
                  )}
                  
                  {/* 图片网格布局 - 一排3张图片 */}
                  <div className="grid grid-cols-3 gap-3">
                    {imageHistory.map((image) => (
                      <motion.div 
                        key={image.id}
                        className={`bg-white/80 backdrop-blur-sm rounded-xl overflow-hidden shadow-lg ${
                          isManageMode && selectedImages.includes(image.id) 
                            ? "ring-2 ring-[#22c55e]" 
                            : ""
                        }`}
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ duration: 0.3 }}
                      >
                        <div className="p-2 relative">
                          {/* 管理模式下显示复选框 */}
                            {isManageMode && (
                              <div
                                className="absolute top-1 right-1 w-5 h-5 rounded-full bg-white flex items-center justify-center z-10 shadow-md"
                              >
                                {selectedImages.includes(image.id) ? (
                                  <i className="fa-solid fa-check text-[#22c55e] text-xs"></i>
                                ) : (
                                  <i className="fa-regular fa-square text-[#16a34a] text-xs"></i>
                                )}
                              </div>
                            )}
                          
                            {/* 修复结果图片 - 根据是否管理模式决定点击行为 */}
                            <div 
                              className="aspect-square bg-gray-100 rounded-lg overflow-hidden flex items-center justify-center cursor-pointer"
                              onClick={() => {
                                if (isManageMode) {
                                  // 管理模式下点击只勾选
                                  handleImageSelect(image.id);
                                } else {
                                  // 非管理模式下点击弹出大图预览
                                  handleImagePreview(image.restoredImage);
                                }
                              }}
                            >
                              <img 
                                src={image.restoredImage} 
                                alt="修复后" 
                                className="w-full h-full object-cover"
                              />
                            </div>
                          
                          {/* 时间 - 简化显示 */}
                          <p className="text-xs text-[#16a34a]/70 mt-2 truncate">
                            {image.timestamp.split(' ')[0]}
                          </p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </>
              ) : (
                <div className="bg-white/80 backdrop-blur-sm rounded-xl p-8 text-center">
                  <i className="fa-solid fa-image text-[#86efac] text-3xl mb-3"></i>
                  <p className="text-[#16a34a]/70 text-sm">暂无修复记录</p>
                  <button
                    onClick={() => navigate('/')}
                    className="mt-4 px-4 py-2 bg-[#22c55e] text-white text-sm rounded-full"
                  >
                    立即修复
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </motion.div>
      
       {/* 底部导航 */}
      <motion.div 
        className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-md border-t border-[#86efac] flex justify-around py-3 px-6"
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ delay: 0.5, duration: 0.5 }}
      >
<motion.div 
  className="modern-nav-item"
  onClick={() => navigate('/')}
  whileHover={{ scale: 1.03 }}
  whileTap={{ scale: 0.98 }}
>
  <i className="fa-solid fa-paint-brush"></i>
  <span>修复台</span>
</motion.div>
        <motion.div 
          className="modern-nav-item active"
          onClick={() => navigate('/profile')}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.98 }}
        >
           <i className="fa-solid fa-user"></i>
           <span>个人中心</span>
         </motion.div>
      </motion.div>
      
      {/* 图片预览模态框 */}
      {showImagePreview && (
        <motion.div 
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleClosePreview}
        >
          <motion.div 
            className="relative max-w-4xl max-h-[90vh] flex flex-col items-center justify-center"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
          >
            {/* 关闭按钮 */}
            <button 
              className="absolute -top-12 right-0 w-8 h-8 rounded-full bg-red-500 text-white flex items-center justify-center shadow-md z-10"
              onClick={handleClosePreview}
            >
              <i className="fa-solid fa-times"></i>
            </button>
            
            {/* 预览图片 */}
            <div className="relative max-w-full max-h-[80vh]">
              <img 
                src={previewImageUrl} 
                alt="大图预览" 
                className="max-w-full max-h-[80vh] object-contain rounded-lg"
              />
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}