import { useState } from "react";
import { toast } from "sonner";
import type { RequestInit } from 'undici';

// 模拟修复后的图片URL（用于API调用失败时展示效果）
const mockRestoredImage = "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Restored%20vintage%20photo%20with%20high%20quality%20and%20clarity&sign=7c53dc2468ae30f6dc56f76fcdd37074";

// API调用配置
const API_CONFIG = {
  url: "https://photo-restore-api.vercel.app/api/restore",
  timeout: 30000, // 30秒超时
  maxRetries: 1   // 重试次数
};

interface UsePhotoRestoreReturn {
  resultUrl: string | null;
  error: string | null;
  loading: boolean;
  restorePhoto: (file: File) => Promise<void>;
  useSampleResult: () => void;
  clearResult: () => void;
}

export const usePhotoRestore = (): UsePhotoRestoreReturn => {
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // 清除结果和错误
  const clearResult = () => {
    setResultUrl(null);
    setError(null);
  };

  // 使用示例修复结果
  const useSampleResult = () => {
    setResultUrl(mockRestoredImage);
    setError(null);
    toast.info("当前展示的是示例修复结果");
  };

  // 带超时的fetch请求
  const fetchWithTimeout = (url: string, options: RequestInit): Promise<Response> => {
    return new Promise((resolve, reject) => {
      const controller = new AbortController();
      const signal = controller.signal;
      
      // 设置超时
      const timeoutId = setTimeout(() => {
        controller.abort();
        reject(new Error("请求超时，请检查网络连接"));
      }, API_CONFIG.timeout);

      // 创建一个新的FormData对象，避免浏览器自动添加参数
      let fetchOptions = { ...options, signal };
      
      // 确保不添加任何额外的参数
      fetch(url, fetchOptions)
        .then((response) => {
          clearTimeout(timeoutId);
          resolve(response);
        })
        .catch((err) => {
          clearTimeout(timeoutId);
          reject(err);
        });
    });
  };

  // 执行API调用
  const performApiCall = async (file: File, retriesLeft: number): Promise<string> => {
    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetchWithTimeout(API_CONFIG.url, {
        method: "POST",
        body: formData
      });

      if (!response.ok) {
        throw new Error(`HTTP错误 ${response.status}`);
      }

      const data = await response.json();
      
      // 查找正确的返回字段
      const restoredImageUrl = data.imageUrl || data.output_url;
      
      if (restoredImageUrl) {
        return restoredImageUrl;
      } else {
        // 如果API调用成功但没有返回图片，使用模拟数据确保用户体验
        toast.info("API调用成功，但返回数据不完整，显示示例结果");
        return mockRestoredImage;
      }
    } catch (err: any) {
      // 如果还有重试次数，就重试
      if (retriesLeft > 0) {
        toast.info(`请求失败，正在重试... (剩余 ${retriesLeft} 次)`);
        // 延迟重试，避免请求过于频繁
        await new Promise(resolve => setTimeout(resolve, 1000));
        return performApiCall(file, retriesLeft - 1);
      }
      
      // 没有重试次数了，抛出错误
      throw err;
    }
  };

  // 解析错误信息
  const getDetailedErrorMessage = (err: any): string => {
    let errorMessage = "API调用失败: ";
    
    if (err.name === "TypeError") {
      if (err.message.includes("Failed to fetch") || err.message.includes("NetworkError")) {
        errorMessage += "无法连接到服务器，请检查网络连接或稍后再试";
      } else if (err.message.includes("AbortError") || err.message.includes("请求超时")) {
        errorMessage += "请求超时，服务器响应时间过长";
      } else {
        errorMessage += err.message || "网络错误";
      }
    } else if (err.message.includes("404")) {
      errorMessage += "API地址不存在";
    } else if (err.message.includes("403")) {
      errorMessage += "没有访问权限";
    } else if (err.message.includes("5")) {
      errorMessage += "服务器内部错误，请稍后再试";
    } else if (err.message.includes("未返回")) {
      errorMessage += "API返回数据格式不正确";
    } else {
      errorMessage += err.message || "未知错误";
    }
    
    return errorMessage;
  };

  // 修复照片的主要函数
  const restorePhoto = async (file: File) => {
    setLoading(true);
    setError(null);
    setResultUrl(null);

    try {
      // 尝试API调用
      const restoredImageUrl = await performApiCall(file, API_CONFIG.maxRetries);
      
      setResultUrl(restoredImageUrl);
      toast.success("照片修复成功！");
    } catch (err: any) {
      // 更详细的错误日志记录
      console.error("API调用失败详情:", {
        message: err.message,
        stack: err.stack,
        name: err.name,
        fullError: err
      });
      
      // 显示详细的错误信息
      const detailedError = getDetailedErrorMessage(err);
      setError(detailedError);
      toast.error("修复过程中发生错误");
    } finally {
      setLoading(false);
    }
  };

  return {
    resultUrl,
    error,
    loading,
    restorePhoto,
    useSampleResult,
    clearResult
  };
};