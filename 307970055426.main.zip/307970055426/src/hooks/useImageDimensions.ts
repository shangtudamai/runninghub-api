import { useState, useEffect } from 'react';

/**
 * 用于获取图片原始尺寸的Hook
 * @param imageUrl 图片URL
 * @param defaultAspectRatio 默认宽高比 (width/height)
 * @returns 包含图片尺寸信息的对象
 */
export function useImageDimensions(
  imageUrl: string | null,
  defaultAspectRatio: number = 1 // 默认正方形
) {
  const [dimensions, setDimensions] = useState({
    width: 0,
    height: 0,
    aspectRatio: defaultAspectRatio,
    isLandscape: defaultAspectRatio >= 1,
    isPortrait: defaultAspectRatio < 1,
    isLoading: true
  });

  useEffect(() => {
    if (!imageUrl) {
      setDimensions({
        width: 0,
        height: 0,
        aspectRatio: defaultAspectRatio,
        isLandscape: defaultAspectRatio >= 1,
        isPortrait: defaultAspectRatio < 1,
        isLoading: false
      });
      return;
    }

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const aspectRatio = img.width / img.height;
      setDimensions({
        width: img.width,
        height: img.height,
        aspectRatio,
        isLandscape: aspectRatio >= 1,
        isPortrait: aspectRatio < 1,
        isLoading: false
      });
    };
    img.onerror = () => {
      setDimensions({
        width: 0,
        height: 0,
        aspectRatio: defaultAspectRatio,
        isLandscape: defaultAspectRatio >= 1,
        isPortrait: defaultAspectRatio < 1,
        isLoading: false
      });
    };
    img.src = imageUrl;

    return () => {
      // 清理函数，避免内存泄漏
      img.onload = null;
      img.onerror = null;
    };
  }, [imageUrl, defaultAspectRatio]);

  return dimensions;
}